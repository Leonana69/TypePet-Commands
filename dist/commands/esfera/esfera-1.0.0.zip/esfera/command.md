---
name: esfera
kind: image
usage: /esfera
help: Show the Esfera guide image.
image: esfera.png
holdSeconds: 120
version: 1.0.0
author: leonana69
minAppVersion: 0.1.0
tags: maplestory, guide, image
---
