---
name: ssc
kind: clipboard
usage: /ssc
help: Copy "Sacred Symbol/claim" to the clipboard.
clipboard: Sacred Symbol/claim
version: 1.0.0
author: leonana69
minAppVersion: 1.0.0
tags: maplestory, clipboard, macro
---
