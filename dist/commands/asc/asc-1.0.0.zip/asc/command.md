---
name: asc
kind: clipboard
usage: /asc
help: Copy "Arcane Symbol/claim" to the clipboard.
clipboard: Arcane Symbol/claim
version: 1.0.0
author: leonana69
minAppVersion: 0.1.0
tags: maplestory, clipboard, macro
---
